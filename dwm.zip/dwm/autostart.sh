#!/bin/bash

dwm-status-bar &
dmenu_run -b -sb grey -sf black  -p 'BlackarchMenu'  -fn 'Terminus-12' &
#dmenu_launch &
